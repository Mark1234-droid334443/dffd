import { createFileRoute } from '@tanstack/react-router'
import { Phone, MapPin, Clock, Star, Coffee, Cake, Utensils, Heart } from 'lucide-react'
import { useState } from 'react'
import { useMutation } from 'convex/react'
import { api } from '../../convex/_generated/api'

export const Route = createFileRoute('/')({
  head: () => ({
    meta: [
      { title: 'Das verspielte Café | Gemütliches Café in Korb bei Stuttgart' },
      { name: 'description', content: 'Besuchen Sie Das verspielte Café in Korb (Kirchstraße 2). Hausgemachter Kuchen, bester Cappuccino und eine familiäre Atmosphäre im Rems-Murr-Kreis.' },
      { name: 'keywords', content: 'Cafe Korb, Das verspielte Cafe, Kuchen Korb, Cappuccino Korb, Cafe Rems-Murr, Frühstück Korb' },
      { property: 'og:title', content: 'Das verspielte Café — Korb' },
      { property: 'og:description', content: 'Ihr gemütliches Wohnzimmer in Korb. Hausgemachte Speisen & herzliche Atmosphäre.' },
      { property: 'og:type', content: 'website' },
    ],
    scripts: [
      {
        type: 'application/ld+json',
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Cafe",
          "name": "Das verspielte Café",
          "image": "https://images.unsplash.com/photo-1554118811-1e0d58224f24",
          "@id": "",
          "url": "https://www.das-verspielte-cafe.de",
          "telephone": "+4971512063444",
          "address": {
            "@type": "PostalAddress",
            "streetAddress": "Kirchstraße 2",
            "addressLocality": "Korb",
            "postalCode": "71404",
            "addressRegion": "Baden-Württemberg",
            "addressCountry": "DE"
          },
          "geo": {
            "@type": "GeoCoordinates",
            "latitude": 48.8415,
            "longitude": 9.3625
          },
          "openingHoursSpecification": [
            {
              "@type": "OpeningHoursSpecification",
              "dayOfWeek": ["Monday", "Tuesday", "Thursday", "Friday"],
              "opens": "11:00",
              "closes": "18:00"
            }
          ],
          "sameAs": [
            "https://www.facebook.com/dasverspieltecafe",
            "https://www.instagram.com/dasverspieltecafe"
          ]
        })
      }
    ]
  }),
  component: LandingPage,
})

const MAINTENANCE_MODE = false

function LandingPage() {
  const [formData, setFormData] = useState({ name: '', email: '', message: '' })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const sendMessage = useMutation(api.contact.sendMessage)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    try {
      await sendMessage(formData)
      alert('Vielen Dank für Ihre Nachricht! Wir melden uns in Kürze bei Ihnen.')
      setFormData({ name: '', email: '', message: '' })
    } catch (error) {
      alert('Es gab einen Fehler beim Senden der Nachricht. Bitte rufen Sie uns stattdessen an.')
    } finally {
      setIsSubmitting(false)
    }
  }

  if (MAINTENANCE_MODE) {
    return (
      <div className="min-h-screen bg-brand-cream flex items-center justify-center p-4 text-center">
        <div className="max-w-md space-y-8 p-12 bg-white rounded-3xl shadow-xl border-2 border-brand-green/10">
          <div className="w-20 h-20 bg-brand-green rounded-full flex items-center justify-center mx-auto animate-pulse">
            <Heart className="text-white w-10 h-10" fill="currentColor" />
          </div>
          <div className="space-y-4">
            <h1 className="text-3xl font-serif text-brand-green">Das verspielte Café</h1>
            <p className="text-xl text-brand-terracotta italic font-serif">„Wir machen uns gerade hübsch für Sie!“</p>
            <p className="text-gray-600 leading-relaxed">
              Unsere Website befindet sich momentan im Wartungsmodus. Wir sind bald wieder mit frischem Kaffee und hausgemachtem Kuchen für Sie da.
            </p>
          </div>
          <div className="pt-6 border-t border-brand-green/10 space-y-2">
            <p className="font-bold text-brand-green">Sie erreichen uns weiterhin unter:</p>
            <a href="tel:071512063444" className="text-xl font-bold hover:text-brand-terracotta transition-colors">
              07151 2063444
            </a>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="flex flex-col min-h-screen bg-brand-cream text-gray-800">
      {/* Fixed Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-md border-b border-brand-green/10">
        <div className="container mx-auto px-4 py-3 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-brand-green rounded-full flex items-center justify-center">
              <Heart className="text-white w-6 h-6" fill="currentColor" />
            </div>
            <span className="font-serif text-xl font-bold text-brand-green leading-none">
              Das verspielte <br /> Café
            </span>
          </div>
          
          <div className="hidden md:flex gap-8 font-medium">
            <a href="#highlights" className="hover:text-brand-green transition-colors">Angebote</a>
            <a href="#uber-uns" className="hover:text-brand-green transition-colors">Über uns</a>
            <a href="#kontakt" className="hover:text-brand-green transition-colors">Kontakt</a>
          </div>

          <a 
            href="tel:071512063444" 
            className="flex items-center gap-2 bg-brand-green text-white px-4 py-2 rounded-full font-bold hover:bg-opacity-90 transition-all shadow-md active:scale-95"
          >
            <Phone size={18} />
            <span className="hidden sm:inline">07151 2063444</span>
            <span className="sm:hidden">Anrufen</span>
          </a>
        </div>
      </header>

      <main className="pt-20">
        {/* Hero Section */}
        <section className="relative py-16 md:py-24 overflow-hidden">
          <div className="container mx-auto px-4 relative z-10 grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <div className="inline-flex items-center gap-2 bg-brand-rose/30 text-brand-terracotta px-3 py-1 rounded-full text-sm font-bold uppercase tracking-wider">
                <Heart size={14} fill="currentColor" /> Herzlich & Familiär
              </div>
              <h1 className="text-4xl md:text-6xl text-brand-green leading-tight">
                Ihr gemütliches Wohnzimmer in Korb
              </h1>
              <p className="text-lg md:text-xl text-gray-600 max-w-lg">
                Genießen Sie hausgemachte Köstlichkeiten, feinste Kaffeespezialitäten und eine Atmosphäre, die zum Verweilen einlädt.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <a 
                  href="tel:071512063444"
                  className="bg-brand-green text-white text-center px-8 py-4 rounded-xl font-bold text-lg shadow-lg hover:shadow-xl transition-all"
                >
                  Jetzt anrufen
                </a>
                <a 
                  href="https://www.google.com/maps/dir//Kirchstraße+2,+71404+Korb"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-white text-brand-green border-2 border-brand-green text-center px-8 py-4 rounded-xl font-bold text-lg hover:bg-brand-green/5 transition-all"
                >
                  Route planen
                </a>
              </div>

              <div className="flex items-center gap-4 text-sm font-medium pt-4">
                <Clock className="text-brand-terracotta" size={20} />
                <span>Nächste Öffnung: <span className="text-brand-green font-bold text-base">Mo ab 11:00 Uhr</span></span>
              </div>
            </div>

            <div className="relative">
              <div className="aspect-[4/5] rounded-3xl overflow-hidden shadow-2xl relative z-10 border-8 border-white">
                <img 
                  src="https://images.unsplash.com/photo-1554118811-1e0d58224f24?q=80&w=1200&auto=format&fit=crop" 
                  alt="Das verspielte Café Interior" 
                  className="w-full h-full object-cover"
                />
              </div>
              {/* Decorative elements */}
              <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-brand-rose rounded-full -z-0 blur-2xl opacity-50"></div>
              <div className="absolute -top-6 -left-6 w-48 h-48 bg-brand-terracotta/10 rounded-full -z-0"></div>
              
              {/* Floating Social Proof */}
              <div className="absolute bottom-10 -left-6 md:-left-12 bg-white p-4 rounded-2xl shadow-xl z-20 flex items-center gap-3">
                <div className="bg-yellow-400 p-2 rounded-lg">
                  <Star fill="white" className="text-white w-6 h-6" />
                </div>
                <div>
                  <div className="flex text-yellow-500 gap-0.5">
                    {[...Array(5)].map((_, i) => <Star key={i} size={14} fill="currentColor" />)}
                  </div>
                  <p className="text-sm font-bold">4,7 Sterne · Google</p>
                  <p className="text-xs text-gray-500">20+ Bewertungen</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Highlights Section */}
        <section id="highlights" className="py-20 bg-white">
          <div className="container mx-auto px-4">
            <div className="text-center max-w-2xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl text-brand-green mb-4">Gaumenfreuden für jeden Moment</h2>
              <p className="text-gray-600 italic">Von herzhaft bis süß — wir bereiten alles mit viel Liebe für Sie zu.</p>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                { 
                  title: 'Cappuccino', 
                  desc: 'Ein absolutes Highlight. Perfekt geschäumt und serviert mit einem Lächeln.',
                  img: 'https://images.unsplash.com/photo-1534778101976-62847782c213?q=80&w=800&auto=format&fit=crop',
                  icon: <Coffee />
                },
                { 
                  title: 'Hausgemachter Kuchen', 
                  desc: 'Täglich frisch gebackene Variationen nach Familienrezepten.',
                  img: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?q=80&w=800&auto=format&fit=crop',
                  icon: <Cake />
                },
                { 
                  title: 'Vielfältige Tees', 
                  desc: 'Eine erlesene Auswahl für entspannte Momente in unserer Sitzecke.',
                  img: 'https://images.unsplash.com/photo-1597481499750-3e6b22637e12?q=80&w=800&auto=format&fit=crop',
                  icon: <Heart />
                },
                { 
                  title: 'Mittagessen', 
                  desc: 'Abwechslungsreiche Tagesgerichte — frisch, regional und lecker.',
                  img: 'https://images.unsplash.com/photo-1547592166-23ac45744acd?q=80&w=800&auto=format&fit=crop',
                  icon: <Utensils />
                }
              ].map((item, i) => (
                <div key={i} className="group cursor-default">
                  <div className="relative aspect-square rounded-2xl overflow-hidden mb-4">
                    <img 
                      src={item.img} 
                      alt={item.title} 
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end p-4">
                      <div className="text-white flex items-center gap-2 font-serif text-lg">
                        {item.icon}
                        {item.title}
                      </div>
                    </div>
                  </div>
                  <p className="text-gray-600 text-sm leading-relaxed">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Why Us / Trust Section */}
        <section className="py-20 bg-brand-rose/20">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl md:text-4xl text-brand-green text-center mb-16 font-serif">Warum das verspielte Café?</h2>
            
            <div className="grid md:grid-cols-3 gap-12">
              {[
                { 
                  title: 'Familiäre Atmosphäre', 
                  desc: 'Bei uns sind Sie nicht nur ein Gast, sondern Teil der Familie. Wir nehmen uns Zeit.',
                  icon: <Heart className="w-10 h-10 text-brand-terracotta" fill="currentColor" opacity="0.2" strokeWidth={1} />
                },
                { 
                  title: 'Hausgemachte Speisen', 
                  desc: 'Alles wird mit frischen Zutaten und viel Leidenschaft direkt bei uns zubereitet.',
                  icon: <Utensils className="w-10 h-10 text-brand-terracotta" strokeWidth={1} />
                },
                { 
                  title: 'Einzigartige Einrichtung', 
                  desc: 'Entdecken Sie unsere liebevolle Vitrine und Accessoires in jedem Winkel.',
                  icon: <Star className="w-10 h-10 text-brand-terracotta" strokeWidth={1} />
                }
              ].map((item, i) => (
                <div key={i} className="text-center space-y-4">
                  <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center mx-auto shadow-sm">
                    {item.icon}
                  </div>
                  <h3 className="text-xl font-bold text-brand-green">{item.title}</h3>
                  <p className="text-gray-600 leading-relaxed max-w-xs mx-auto">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Testimonials */}
        <section className="py-20 bg-white">
          <div className="container mx-auto px-4 overflow-hidden">
             <div className="flex items-center justify-center gap-2 mb-8">
                {[...Array(5)].map((_, i) => <Star key={i} size={20} fill="#EAB308" className="text-yellow-500" />)}
             </div>
             <div className="grid md:grid-cols-3 gap-8">
               {[
                 "Ein sehr schönes und gemütliches Café. Der Cappuccino ist ein absolutes Highlight.",
                 "Man fühlt sich einfach wohl dort und es ist sehr familiär, was einem gut tut.",
                 "Leckeres Essen bei netten Leuten!"
               ].map((quote, i) => (
                 <div key={i} className="p-8 bg-brand-cream rounded-3xl relative">
                   <span className="absolute top-4 left-4 text-brand-rose text-6xl font-serif opacity-50">“</span>
                   <p className="text-lg italic text-gray-700 relative z-10">{quote}</p>
                   <p className="mt-4 font-bold text-sm text-brand-green">— Google Bewertung</p>
                 </div>
               ))}
             </div>
          </div>
        </section>

        {/* Contact & Map Section */}
        <section id="kontakt" className="py-20 bg-brand-green text-white">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-16">
              <div>
                <h2 className="text-3xl md:text-5xl mb-6 leading-tight">Wir freuen uns auf Ihren Besuch!</h2>
                <p className="text-brand-rose/80 text-lg mb-10 max-w-md">
                  Haben Sie Fragen oder möchten Sie einen Tisch reservieren? Schreiben Sie uns oder rufen Sie einfach an.
                </p>

                <div className="space-y-6">
                  <div className="flex items-start gap-4">
                    <div className="bg-white/10 p-3 rounded-xl">
                      <MapPin />
                    </div>
                    <div>
                      <p className="font-bold">Adresse</p>
                      <p className="text-brand-rose/80">Kirchstraße 2, 71404 Korb</p>
                      <a 
                        href="https://www.google.com/maps/dir//Kirchstraße+2,+71404+Korb" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-sm underline hover:text-white transition-colors"
                      >
                        In Google Maps öffnen
                      </a>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="bg-white/10 p-3 rounded-xl">
                      <Phone />
                    </div>
                    <div>
                      <p className="font-bold">Telefon</p>
                      <a href="tel:071512063444" className="text-brand-rose/80 hover:text-white transition-colors">
                        07151 2063444
                      </a>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="bg-white/10 p-3 rounded-xl">
                      <Clock />
                    </div>
                    <div>
                      <p className="font-bold">Öffnungszeiten</p>
                      <div className="text-brand-rose/80 text-sm space-y-1">
                        <p>Mo, Di, Do, Fr: 11:00 – 18:00 Uhr</p>
                        <p>Mi, Sa, So: Ruhetag (Bitte tel. erfragen)</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white rounded-3xl p-8 shadow-2xl">
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div>
                    <label className="block text-gray-700 font-bold mb-2">Ihr Name</label>
                    <input 
                      type="text" 
                      required
                      value={formData.name}
                      onChange={e => setFormData({...formData, name: e.target.value})}
                      className="w-full bg-brand-cream border-transparent focus:border-brand-green border-2 rounded-xl px-4 py-3 text-gray-800 transition-all outline-none"
                      placeholder="Vorname Nachname"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-700 font-bold mb-2">E-Mail Adresse</label>
                    <input 
                      type="email" 
                      required
                      value={formData.email}
                      onChange={e => setFormData({...formData, email: e.target.value})}
                      className="w-full bg-brand-cream border-transparent focus:border-brand-green border-2 rounded-xl px-4 py-3 text-gray-800 transition-all outline-none"
                      placeholder="ihre@email.de"
                    />
                  </div>
                  <div>
                    <label className="block text-gray-700 font-bold mb-2">Ihre Nachricht</label>
                    <textarea 
                      required
                      rows={4}
                      value={formData.message}
                      onChange={e => setFormData({...formData, message: e.target.value})}
                      className="w-full bg-brand-cream border-transparent focus:border-brand-green border-2 rounded-xl px-4 py-3 text-gray-800 transition-all outline-none resize-none"
                      placeholder="Wie können wir Ihnen helfen?"
                    ></textarea>
                  </div>
                  <button 
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-brand-terracotta hover:bg-opacity-90 disabled:opacity-50 text-white font-bold py-4 rounded-xl shadow-lg transition-all active:scale-95 flex justify-center items-center gap-2"
                  >
                    {isSubmitting ? (
                      <>
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                        Wird gesendet...
                      </>
                    ) : 'Nachricht senden'}
                  </button>
                </form>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="py-12 bg-white border-t border-brand-green/5">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Heart className="text-brand-green w-6 h-6" fill="currentColor" />
            <span className="font-serif text-2xl font-bold text-brand-green">Das verspielte Café</span>
          </div>
          <p className="text-brand-terracotta font-serif italic mb-8">„Wo Gemütlichkeit zu Hause ist.“</p>
          
          <div className="flex justify-center gap-6 mb-8 text-brand-green font-medium">
            <span>Folgen Sie uns demnächst auf Instagram & Facebook</span>
          </div>

          <div className="text-sm text-gray-500 space-y-2">
            <p>&copy; {new Date().getFullYear()} Das verspielte Café. Alle Rechte vorbehalten.</p>
            <div className="flex justify-center gap-4">
              <a href="#" className="underline hover:text-brand-green">Impressum</a>
              <a href="#" className="underline hover:text-brand-green">Datenschutz</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
